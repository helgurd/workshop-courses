﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Workshop_Courses_Assignment
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Assign the Variables to be used in the Program.
        Double RegistrationCost;
        Double LodgingCost;
        Double TotalCost;
        Double Days;

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
          
         // Part One: 

             // A: Here user selects Courses 

                // First Declare the string courses.
                string courses;

                // Now let's fool the compiler with a Null Value. 
                courses = " ";

                if (listBoxCourses.SelectedIndex != -1)
                    {
                        courses = listBoxCourses.SelectedItem.ToString();
                        MessageBox.Show("The Course you selected is:  " + courses);
                    }
                else
                {
                    MessageBox.Show("Please Select a Course from the List.");
                }

             // B: 
             // Here user select the location
                // Declare the string location.
                string location;

                // Now with a Null Value let's fool the compiler.
                location = " ";

                if (listBoxLocations.SelectedIndex != -1)
                    {
                        location = listBoxLocations.SelectedItem.ToString();
                        MessageBox.Show("The Location you selected is: " + location);
                    }
                else
                {
                    MessageBox.Show("Please Select a Location from the List.");
                }

               
              // Part Two: 

             

              // User carries out computation with Supervision Skills Selected and Dublin Selected.
             if(courses == "Supervision Skills" && location == "Dublin")
                 {
                    RegistrationCost = 1500;
                    LodgingCost = 900;
                    TotalCost = RegistrationCost + LodgingCost;
                    // Debug: MessageBox.Show("The cost will be: " + Total);
                 } 
                                                                
            // Associatiate Course Type with Length of the Course in Days.
            switch (courses)
            {
                case "Handling Stress":
                    Days = 3;
                    break;
                case "Time Management":
                    Days = 3;
                    break;
                case "Supervision Skills":
                    Days = 3;
                    break;
                case "Negotiation":
                    Days = 5;
                    break;
                case "How to Interview":
                    Days = 1;
                    break;
            }
            

            // Associate Course Type with Registeration Fee.
            switch (courses)
            {
                case "Handling Stress":
                    RegistrationCost = 1000;
                    break;
                case "Time Management":
                    RegistrationCost = 800;
                    break;
                case "Supervision Skills":
                    RegistrationCost = 1500;
                    break;
                case "Negotiation":
                    RegistrationCost = 1300;
                    break;
                case "How to Interview":
                    RegistrationCost = 500;
                    break;
            }
             

           // Associate the Location with the Lodging Fees.
           switch (location)
            {
                case "Dublin":
                    LodgingCost = 300;
                    break;
                case "Belfast":
                    LodgingCost = 250;
                    break;
                case "Galway":
                    LodgingCost = 150;
                    break;
                case "Waterford":
                    LodgingCost = 100;
                    break;
                case "Cork":
                    LodgingCost = 300;
                    break;
                case "Kerry":
                    LodgingCost = 100;
                    break;
            }
            
            // Now calculate the Total Cost of the Course.

            TotalCost = RegistrationCost + (LodgingCost * Days);

            
            // Part Three: 
            // Outputting final results

            // Display RegisterationCost.
            Registration.Text = RegistrationCost.ToString();

            // Display Lodging Cost.
            Lodging.Text = LodgingCost.ToString();

            // Display Total Cost.
            Total.Text = TotalCost.ToString();

            // Display Number of Days course will run.
            NumberofDays.Text = Days.ToString();

            // End                       
        }

        private void label4_Click_1(object sender, EventArgs e)
        {

        }

        private void Registration_Click(object sender, EventArgs e)
        {

        }
    }
}
